#ifndef TAR_HEADER_
#define TAR_HEADER_

#include<stdio.h>
#include<string.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<unistd.h>
#include<dirent.h>
#include<errno.h>
#include<tar.h> // for some macros
#include<grp.h>
#include<pwd.h>
#include<math.h>
#include<time.h>
#include<utime.h>


struct tar_header
{ /* byte offset */
char name[100]; /* 0 */
char mode[8]; /* 100 */
char uid[8]; /* 108 */
char gid[8]; /* 116 */
char size[12]; /* 124 */
char mtime[12]; /* 136 */
char chksum[8]; /* 148 */
char typeflag; /* 156 */
char linkname[100]; /* 157 */
char magic[6]; /* 257 */
char version[2]; /* 263 */
char uname[32]; /* 265 */
char gname[32]; /* 297 */
char devmajor[8]; /* 329 */
char devminor[8]; /* 337 */
char prefix[155]; /* 345 */
char pad[12];  /* 500 */
};

// void printTarEntry(char *fileName, char *outputName)
// Parameters: Name of the file that is being tarred, the
// name of the tar file it should append to
// Return Value: Returns an int value used to detect for errors
// Purpose: This function is responsible for adding files to
// a tar file along with their header.
extern int printTarEntry(char *fileName, char *outputName);


// void readTarInfo(char *tarName)
// Parameters: Name of the tar file that is being extracted
// Return Value: Returns an int value used to detect for errors
// Purpose: This function is responsible for decoding and
// printing out everything within tar files.
extern int readTarInfo(char *fileName);

#endif
